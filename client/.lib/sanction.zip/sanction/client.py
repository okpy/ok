from warnings import warn
warn('sanction.client.Client is deprecated, please use sanction.Client')
from sanction import Client
